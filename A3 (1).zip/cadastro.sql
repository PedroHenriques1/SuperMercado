create database cadastro;

use cadastro;

create table usuarios (
	id int auto_increment primary key,
    nome varchar(255),
    senha int not null
);

create table vendedores (
	id int not null auto_increment primary key,
    nome varchar(255) default null,
    senha int not null,
    categoria varchar(255) default null,
    genero varchar(255) default null
);

CREATE TABLE produtos (
    id int AUTO_INCREMENT PRIMARY KEY,
    codigo_barras varchar(100),
    nome varchar(255),
    preco decimal(10,2),
    estoque int,
    descricao varchar(255)
);

CREATE TABLE vendas (
    id int AUTO_INCREMENT PRIMARY KEY,
    produto_id int,
    nome varchar(255),
    quantidade int,
    descricao varchar(255),
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
);

INSERT INTO produtos (codigo_barras, nome, preco, estoque, descricao) VALUES
('CB001', 'Caixa de leite', 10.50, 100, 'Caixa de leite Italac contendo 6 unidades'),
('CB002', 'Kit de panelas', 100.00, 150, 'Kit de panelas da Tramontina contendo 5 unidades'),
('CB003', 'Notebook', 15.75, 80, 'Notebook Samsung com sistema operacional Windows com 8gb de RAM'),
('CB004', 'Iogurte', 12.99, 120, 'Iogurte Batavo de morango com cereais'),
('CB005', 'Carne bovina', 50.00, 100, 'Picanha Friboi 1KG'),
('CB005', 'Blusa', 15.00, 100, 'Blusa de manga longa básica na cor azul'),
('CB006', 'Calça', '15.00', '100', 'Calça de moletom cinza com cordão'),
('CB007', 'Bola', '20.00', '100', 'Bola de Futebol'),
('CB008', 'Saco de arroz', '30.00', '100', 'Saco de Arroz Tio João com 5KG'),
('CB009', 'Açúcar', '6.00', '100', 'Saco de açúcar refinado União com 1KG'),
('CB010', 'Feijão', '10.00', '100', 'Saco de feijão Camil com 1KG');

INSERT INTO usuarios (nome, senha) VALUES
('admin', '12345');

ALTER TABLE usuarios ADD COLUMN funcao VARCHAR(255);
